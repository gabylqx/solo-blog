title: docker 安装 solo 博客 记录
date: '2019-11-18 13:19:19'
updated: '2019-11-18 15:18:56'
tags: [docker]
permalink: /articles/2019/11/18/1574054359234.html
---



```
yum -y install docker

service docker start

docker exec -it mysql bash

docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=你的数据库密码 -d mysql:5.6

mysql -uroot -p你的数据库密码
#注意，我遇到过数据库密码如果最后一位为!时无法部署成功的问题，为何原因暂不明确，建议密码规避感叹号

create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

exit

exit

cd /


mkdir dockerData

mkdir dockerData/nginx dockerData/nginx/conf dockerData/nginx/logs dockerData/nginx/www dockerData/nginx/ssl

docker run --name nginx -p 80:80 -d --rm nginx

```
导出配置文件

* `docker cp nginx:/etc/nginx/nginx.conf /dockerData/nginx/conf/nginx.conf` 导出配置文件 nginx.conf
* `docker cp nginx:/etc/nginx/conf.d /dockerData/nginx/conf/conf.d` 导出配置为你 nginx.conf  
    执行`docker stop nginx`，会自动删除现在的 nginx 容器，然后执行如下命令重新启动一个 nginx 容器


```
docker run -d -p 80:80 --name nginx \
-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \
-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d \
-v /dockerData/nginx/www:/usr/share/nginx/html \
-v /dockerData/nginx/logs:/var/log/nginx nginx

```

* `-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \` 挂载配置文件`nginx.conf`
* `-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d` 挂载配置文件`default.conf`
* `-v /dockerData/nginx/www:/usr/share/nginx/html` 挂载项目文件
* `-v /dockerData/nginx/logs:/var/log/nginx` 挂载配置文件


## 配置 nginx 配置文件
```
cd /dockerData/nginx/conf/conf.d
vim default.conf

# 参考我的配置，配置自己的default.conf文件
server {
    listen       443;
    server_name  localhost;
    ssl on;

    #charset koi8-r;
    #access_log  /var/log/nginx/host.access.log  main;

    ssl_certificate /ssl/1_www.jinjianh.com_bundle.crt;  # ssl 证书目录
    ssl_certificate_key /ssl/2_www.jinjianh.com.key;
    ssl_session_timeout 5m;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;

    location / {
        root   /usr/share/nginx/html;
        index  index.html index.htm;
    }
# ......
}
server{
  listen 80;
  server_name localhost;
  rewrite ^(.*) https://$host$1 permanent;
}
# 按esc，然后输入:wq保持退出

```
申请SSL证书后把`Nginx`下的两个文件上传至服务器`/dockerDat/nginx/ssl`目录下

## 启动nginx
```
docker stop nginx  # 停止容器
docker rm nginx # 删除容器

docker run -d -p 80:80 -p 443:443 --name nginx \ 
-v /dockerData/nginx/conf/nginx.conf:/etc/nginx/nginx.conf \ 
-v /dockerData/nginx/conf/conf.d:/etc/nginx/conf.d \ 
-v /dockerData/nginx/ssl:/ssl/ \ 
-v /dockerData/nginx/www:/usr/share/nginx/html \ 
-v /dockerData/nginx/logs:/var/log/nginx nginx  
```
## 启动solo容器

```
docker run --detach --name solo --network=host \ 
--env RUNTIME_DB="MYSQL" \ 
--env JDBC_USERNAME="root" \ 
--env JDBC_PASSWORD="123123" \ 
--env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \ 
--env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \ 
b3log/solo --listen_port=8080 --server_scheme=https --server_host=域名 --server_port=  
#如果不弄ssl证书`--server_scheme=https`换成`--server_scheme=http` 

```

配置 nginx 配置文件，实现 nginx 反向代理
```
cd /dockerData/nginx/conf/conf.d
vim default.conf

location / {
        proxy_pass http://域名:8080;
    }
```

替换上面部分即可



重启 nginx
```
docker restart nginx
```

## [Enjoy~](http://www.baidu.com/link?url=TQRvHajU5RRMNQKoiJkxGpnM4LlN8sX6LfC-5SChXsgrLIKbo7NuLYaSR35MZsTw9KAf-GFWMHpQh-0iVaHSlCWrhJ6Fo6ThAn_yDgVbiKK)



### solo的github地址：[点击访问](https://github.com/b3log/solo)
