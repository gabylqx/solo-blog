title: 'mysql  [Err] 1055报错解决，[Err] 1055 – Expression #1 of ORDER BY clause is not
  in GROUP BY'
date: '2019-11-11 10:23:31'
updated: '2019-11-11 10:23:31'
tags: [待分类]
permalink: /articles/2019/11/11/1573439011069.html
---

**问题为：**[Err] 1055 - Expression #1 of ORDER BY clause is not in GROUP BY clause and contains nonaggregated column 'information_schema.PROFILING.SEQ' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by****


报错执行语句：

```
select count(*) from tg_recruitment t  
   LEFT JOIN tg_office office ON office.name=  t.center  
   LEFT JOIN tg_recruitment_result result ON result.recruitment_id=t.id  
WHERE 1=1
```
出错原因：
**sql语句违背了sql_mode=only_full_group_by。**

解决方案：
```
show variables like "sql_mode";
 
set sql_mode='';
set sql_mode='NO_ENGINE_SUBSTITUTION,STRICT_TRANS_TABLES';
```

再次执行语句结果：

```
[SQL]select count(*) from tg_recruitment t
        LEFT JOIN tg_office office ON office.name=  t.center
        LEFT JOIN tg_recruitment_result result ON result.recruitment_id=t.id
WHERE 1=1

受影响的行: 0
时间: 0.666s

```

完美解决报错
